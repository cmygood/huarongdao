# -*- coding: UTF-8 -*-
# encoding=gbk

from PIL import Image
import math
import operator
from functools import reduce
import glob
import random
import os, base64

with open(r'F:\华容道\64.txt', "r") as f:
    # str =''
    imgdata = base64.b64decode(f.read())
    file = open('zzzz.jpg', 'wb')
    file.write(imgdata)
    file.close()

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
    return False



def compare(pic1,pic2):

    image1 = Image.open(pic1)
    image2 = Image.open(pic2)

    histogram1 = image1.histogram()
    histogram2 = image2.histogram()

    differ = math.sqrt(reduce(operator.add, list(map(lambda a,b: (a-b)**2,histogram1, histogram2)))/len(histogram1))

    # print(differ)
    if differ == 0:
        s1 = pic2
        return s1[7]
    else:
        return 0

def compare1(pic1,pic2):

    image1 = Image.open(pic1)
    image2 = Image.open(pic2)

    histogram1 = image1.histogram()
    histogram2 = image2.histogram()

    differ = math.sqrt(reduce(operator.add, list(map(lambda a,b: (a-b)**2,histogram1, histogram2)))/len(histogram1))

    # print(differ)
    if differ == 0:
        s2 = pic2
        if is_number(s2[8]) == False:
            return int(s2[9])+1
        else:
            return int(s2[8])+1
    else:
        return 0



im = Image.open(r'zzzz.jpg')
img_size = im.size
m = img_size[0]    #读取图片的宽度
n = img_size[1]     #读取图片的高度
w = 300                  #设置你要裁剪的小图的宽度
h = 300                  #设置你要裁剪的小图的高度
x = 0
y = 0
a = 0
for i in range(3):         #裁剪为100张随机的小图
    for j in range(3):
        region = im.crop((300*i, 300*j, 300*i+w, 300*j+h)) #裁剪区域
        region.save("zzz" + str(a) + ".jpg")
        a = a+1



list1 = glob.glob(r'F:\华容道\*.jpg')
list2 = glob.glob(r'F:\华容道\zzz*.jpg')
lio = []
x3 = 0
x4 = 0
for i in range(325):
    x1 = compare(r'F:\华容道\zzz0.jpg', list1[i])
    if x1 != 0 :
        for j in range(i-9,i+9):
            x2 = compare(r'F:\华容道\zzz1.jpg', list1[j])
            if x2 == x1 :
                print(x2)
                x3 = 1
                # s2 = list1[j]
                # if is_number(s2[8]) == False:
                #     lio.append(int(s2[9]))
                # else:
                #     lio.append(int(s2[8]))
                break
    if x3 == 1 :
        x4 = i-8
        break

i = 0
temp1 = 0
for i in range(9):
    temp1 = compare(r'F:\华容道\1111111.jpg', list2[i])
    if temp1 != 0:
        temp1 = i+1
        break

i = 0
j = 0

for i in range(9):
    for j in range(18):
        temp = compare1(list2[i],list1[x4+j])
        if temp != 0:
            if x2 ==list1[x4+j][7]:
                lio.append(temp)
                break
        if j == 17 :
            lio.append(temp1)

print(lio)